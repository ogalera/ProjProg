														########################
														#			PACMAN RETURNS               #
														#     Projecte de Programacio            #
														#		Moises Saus Ten                      #
														#		Oscar Galera i Alfaro                #
														########################
														
														            ## README  ##

En el enunciat de la tercera Practica es demana:
 1. Descripci� del projecte desenvolupat: Es troba a: Projecte/Documents/DescripcioProjecte.pdf
 2. Documents pdf:
		2.1 Definici� de tipus abstractes de dades i m�duls funcionals:
				Es troba a: Projecte/Documents/Especificacio.pdf
		2.2 Diagrama de m�duls, on constin els diferents tipus abstractes i m�duls funcionals :
				Es troba a: Projecte/Documents/
 3. Codi font: Es troba a Projecte/Codi/
 4. Documentaci� del codi font en Html: Es troba a Projecte/Documents/DocumentacioHTML/inici.html
 5. Fitxer JAR amb els fitxers .class: Es troba a Projecte/PacmanReturns/
 6. Instruccions d'execuci� a partir del .Jar: Es troba a Projecte/InstruccionsJar.txt
 7. Instruccions de funcionament del programa: Es troba a Projecte/Documents/InstruccionsPacmanReturns.pdf
 
				
     