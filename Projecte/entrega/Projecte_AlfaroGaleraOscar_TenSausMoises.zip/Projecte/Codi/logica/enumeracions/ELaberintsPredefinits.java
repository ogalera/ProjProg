
package logica.enumeracions;

/**
 *
 * @author oscar
 * @brief laberints que tenim predefinits en l'aplicació.
 */
public enum ELaberintsPredefinits {
    LABERINT_ALEATORI, LABERINT_LINEAL_HORITZONTAL, LABERINT_LINEAL_VERTICAL;
}
