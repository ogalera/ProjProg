var searchData=
[
  ['tancarpartida',['tancarPartida',['../classlogica_1_1_partida.html#add05723aee1bf8587d0021f96f372c51',1,'logica::Partida']]],
  ['trobacamimescurt',['trobaCamiMesCurt',['../classlogica_1_1algoritmica_1_1_a_estrella_1_1_buscador_cami_minim.html#a31bce579bd1b302c4eaa16f981655454',1,'logica::algoritmica::AEstrella::BuscadorCamiMinim']]],
  ['trobarcamimaximitzardist',['trobarCamiMaximitzarDist',['../classlogica_1_1algoritmica_1_1_gestor_camins.html#abe60dac7f02241b56588f5518a4442ea',1,'logica::algoritmica::GestorCamins']]],
  ['trobarcamiminim',['trobarCamiMinim',['../classlogica_1_1algoritmica_1_1_gestor_camins.html#a5d7198aa32d0be2a72e15eda16f2ba3d',1,'logica::algoritmica::GestorCamins']]]
];
