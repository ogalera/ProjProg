var searchData=
[
  ['marcador',['Marcador',['../classinterficie_1_1components_1_1_marcador.html',1,'interficie::components']]]
];
