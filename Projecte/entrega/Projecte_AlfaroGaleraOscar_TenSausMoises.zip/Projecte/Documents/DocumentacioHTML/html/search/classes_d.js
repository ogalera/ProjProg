var searchData=
[
  ['solucio',['Solucio',['../classlogica_1_1algoritmica_1_1_back_tracking_1_1_solucio.html',1,'logica::algoritmica::BackTracking']]]
];
