var searchData=
[
  ['gestorcamins',['GestorCamins',['../classlogica_1_1algoritmica_1_1_gestor_camins.html',1,'logica::algoritmica']]]
];
