var searchData=
[
  ['realitzarmoviment',['realitzarMoviment',['../classlogica_1_1_fantasma1.html#aedd0d00456866065de043652fc783c68',1,'logica.Fantasma1.realitzarMoviment()'],['../classlogica_1_1_fantasma2.html#a68af5e9cfac40d91de9bf24fc8042ce1',1,'logica.Fantasma2.realitzarMoviment()'],['../classlogica_1_1_item_movible.html#aa1d46015999f809171a3ad284e249670',1,'logica.ItemMovible.realitzarMoviment()'],['../classlogica_1_1_pacman.html#aa93e730a6089b7670e3b4b20944a7893',1,'logica.Pacman.realitzarMoviment()'],['../classlogica_1_1_personatge.html#a39387dbfebd1936e63c29c8a9dd85bb1',1,'logica.Personatge.realitzarMoviment()']]],
  ['redimensionarimatge',['redimensionarImatge',['../classlogica_1_1_utils.html#a5c0e404e667ec5f7fdac6a244b224098',1,'logica.Utils.redimensionarImatge(ImageIcon imatge, int px)'],['../classlogica_1_1_utils.html#aaf930ea3e64076e1058757013226f044',1,'logica.Utils.redimensionarImatge(BufferedImage originalImage, int tipus, int amplada, int altura)']]],
  ['redimensionarimatges',['redimensionarImatges',['../enumlogica_1_1enumeracions_1_1_e_element.html#a463fe7d8bef930e62019d223bc2f0ed6',1,'logica::enumeracions::EElement']]],
  ['reiniciarpunts',['reiniciarPunts',['../classlogica_1_1_personatge.html#afed860920a63cbd1efe126315a7370f4',1,'logica::Personatge']]],
  ['reiniciarpuntsenemic',['reiniciarPuntsEnemic',['../classlogica_1_1_partida.html#a169e110dd937b6b85725545e8048624e',1,'logica::Partida']]],
  ['reiniciarpuntspacman',['reiniciarPuntsPacman',['../classlogica_1_1_partida.html#ac892458094c3a52cdeb4745e8b1179c4',1,'logica::Partida']]],
  ['reprodueixaparicioitem',['reprodueixAparicioItem',['../classlogica_1_1_audio.html#af34af5f6c05baea4b1044beda801581b',1,'logica::Audio']]],
  ['reprodueixinici',['reprodueixInici',['../classlogica_1_1_audio.html#a5079c1c587da3b4bf704b5e20314b0c5',1,'logica::Audio']]],
  ['reprodueixmenjaitem',['reprodueixMenjaItem',['../classlogica_1_1_audio.html#a6a897d93efd13a0c96d4518bf7e041c0',1,'logica::Audio']]],
  ['reprodueixmenjamoneda',['reprodueixMenjaMoneda',['../classlogica_1_1_audio.html#a36e406167c180e2bdb7c646c7a4c645d',1,'logica::Audio']]],
  ['reprodueixsubstracciopunts',['reprodueixSubstraccioPunts',['../classlogica_1_1_audio.html#ada3a781e4d6bb88233054514b439540d',1,'logica::Audio']]],
  ['reset',['reset',['../classlogica_1_1algoritmica_1_1_a_estrella_1_1_buscador_cami_minim.html#a78037be2355dc5a782185a0d1662ce5c',1,'logica.algoritmica.AEstrella.BuscadorCamiMinim.reset()'],['../classlogica_1_1algoritmica_1_1_back_tracking_1_1_solucio.html#ac695cbcd0dc5a3d5e9da492244718681',1,'logica.algoritmica.BackTracking.Solucio.reset()'],['../classlogica_1_1algoritmica_1_1_casella.html#a8ed287353991f4b700bc45145dc00ab7',1,'logica.algoritmica.Casella.reset()']]],
  ['run',['run',['../classinterficie_1_1components_1_1_crono.html#a0ecb7df579cc0a6476c56517afd50627',1,'interficie::components::Crono']]]
];
