var searchData=
[
  ['objectiu',['Objectiu',['../classlogica_1_1_fantasma3_1_1_objectiu.html',1,'logica::Fantasma3']]]
];
