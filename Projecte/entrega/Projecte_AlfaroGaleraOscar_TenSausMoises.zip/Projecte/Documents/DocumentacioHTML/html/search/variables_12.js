var searchData=
[
  ['valor_5fmoneda_5fextra',['VALOR_MONEDA_EXTRA',['../classlogica_1_1_utils_1_1_constants.html#a705b60aac1d5b26f649dfd4f140f58f5',1,'logica::Utils::Constants']]],
  ['valor_5fmoneda_5fnormal',['VALOR_MONEDA_NORMAL',['../classlogica_1_1_utils_1_1_constants.html#a3067332b704101e903fa39850e86fcf2',1,'logica::Utils::Constants']]]
];
