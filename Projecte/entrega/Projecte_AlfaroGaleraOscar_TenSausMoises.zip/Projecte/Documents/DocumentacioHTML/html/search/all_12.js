var searchData=
[
  ['tan_5fx_5fcent_5fmonedes_5fextra',['TAN_X_CENT_MONEDES_EXTRA',['../classlogica_1_1_utils_1_1_constants.html#a12c59fe7e3530867e1c46c16eda91e0f',1,'logica::Utils::Constants']]],
  ['tan_5fx_5fcent_5fmonedes_5fitem',['TAN_X_CENT_MONEDES_ITEM',['../classlogica_1_1_utils_1_1_constants.html#a8e475dac7825a44136e88d67eea69001',1,'logica::Utils::Constants']]],
  ['tancarpartida',['tancarPartida',['../classlogica_1_1_partida.html#add05723aee1bf8587d0021f96f372c51',1,'logica::Partida']]],
  ['tascaaplicarmoviment',['TascaAplicarMoviment',['../classlogica_1_1_item_movible_1_1_tasca_aplicar_moviment.html',1,'logica::ItemMovible']]],
  ['tauler',['tauler',['../classlogica_1_1algoritmica_1_1_a_estrella_1_1_buscador_cami_minim.html#a2ed56315845fb53a3709fe045f3dfe2e',1,'logica.algoritmica.AEstrella.BuscadorCamiMinim.tauler()'],['../classlogica_1_1algoritmica_1_1_back_tracking_1_1_solucio.html#abb4b1b2f358a83b83f378793cc3dae5e',1,'logica.algoritmica.BackTracking.Solucio.tauler()'],['../classlogica_1_1laberints_1_1_laberint.html#adf27aa8fa875b4a3f996756bc5cf9e69',1,'logica.laberints.Laberint.tauler()']]],
  ['temps_5fefectes_5fitem_5fmilisegons',['TEMPS_EFECTES_ITEM_MILISEGONS',['../classlogica_1_1_utils_1_1_constants.html#ab30ed70143525f71ad7d7d6e21cff608',1,'logica::Utils::Constants']]],
  ['tempstotalcalcul',['tempsTotalCalcul',['../classlogica_1_1_item_movible.html#acc514a1b03e6f87bd157f334837ea7c0',1,'logica::ItemMovible']]],
  ['tipuselement',['tipusElement',['../classlogica_1_1_item.html#a8f4061141a64a72969be035b8d689fb9',1,'logica::Item']]],
  ['top_5fn_5fdel_5franking',['TOP_N_DEL_RANKING',['../classlogica_1_1_utils_1_1_constants.html#a0fd652b6e00ec4f847dbfd8a18b27384',1,'logica::Utils::Constants']]],
  ['trobacamimescurt',['trobaCamiMesCurt',['../classlogica_1_1algoritmica_1_1_a_estrella_1_1_buscador_cami_minim.html#a31bce579bd1b302c4eaa16f981655454',1,'logica::algoritmica::AEstrella::BuscadorCamiMinim']]],
  ['trobarcamimaximitzardist',['trobarCamiMaximitzarDist',['../classlogica_1_1algoritmica_1_1_gestor_camins.html#abe60dac7f02241b56588f5518a4442ea',1,'logica::algoritmica::GestorCamins']]],
  ['trobarcamiminim',['trobarCamiMinim',['../classlogica_1_1algoritmica_1_1_gestor_camins.html#a5d7198aa32d0be2a72e15eda16f2ba3d',1,'logica::algoritmica::GestorCamins']]]
];
