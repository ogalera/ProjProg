var searchData=
[
  ['node',['Node',['../classlogica_1_1historic__moviments_1_1_pila_3_01_t_01_4_1_1_node.html',1,'logica::historic_moviments::Pila&lt; T &gt;']]]
];
