var searchData=
[
  ['bd',['BD',['../classdades_1_1_b_d.html',1,'dades']]],
  ['btncasella',['btnCasella',['../classinterficie_1_1_f_editor_laberint_1_1btn_casella.html',1,'interficie::FEditorLaberint']]],
  ['buscadorcamimaxim',['BuscadorCamiMaxim',['../classlogica_1_1algoritmica_1_1_back_tracking_1_1_buscador_cami_maxim.html',1,'logica::algoritmica::BackTracking']]],
  ['buscadorcamiminim',['BuscadorCamiMinim',['../classlogica_1_1algoritmica_1_1_a_estrella_1_1_buscador_cami_minim.html',1,'logica::algoritmica::AEstrella']]]
];
