var searchData=
[
  ['dada',['dada',['../classlogica_1_1historic__moviments_1_1_pila_3_01_t_01_4_1_1_node.html#a6f4fc083e03ba3766312644951151e2f',1,'logica::historic_moviments::Pila&lt; T &gt;::Node']]],
  ['debugactiu',['debugActiu',['../classinterficie_1_1_f_log.html#af5162801c906c6bd7b8f52723e4dcffe',1,'interficie::FLog']]],
  ['dificultat',['dificultat',['../classlogica_1_1_usuari.html#aa8de7af3235926444f7b27c28a6263b2',1,'logica::Usuari']]],
  ['distancia_5fconsiderable',['DISTANCIA_CONSIDERABLE',['../classlogica_1_1_fantasma3.html#a188d9336f751a28078fc220ee3e61c97',1,'logica::Fantasma3']]],
  ['distancia_5fperillosa',['DISTANCIA_PERILLOSA',['../classlogica_1_1_fantasma3.html#a66b467ba2716d3116b05a06e75282b5e',1,'logica.Fantasma3.DISTANCIA_PERILLOSA()'],['../classlogica_1_1_item.html#aeb47370bb9dfdc7d690d546d74ea0854',1,'logica.Item.DISTANCIA_PERILLOSA()']]],
  ['distanciaalobjectiu',['distanciaAlObjectiu',['../classlogica_1_1algoritmica_1_1_casella.html#ad412db755fc91149053db6100870bf70',1,'logica::algoritmica::Casella']]]
];
