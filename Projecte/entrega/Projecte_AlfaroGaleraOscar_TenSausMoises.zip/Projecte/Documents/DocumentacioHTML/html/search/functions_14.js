var searchData=
[
  ['validarlaberint',['validarLaberint',['../classlogica_1_1_validador_laberint.html#ae68bc2619d7584ee5706305220edf18f',1,'logica.ValidadorLaberint.validarLaberint(int[][] laberint, int costat)'],['../classlogica_1_1_validador_laberint.html#ab3c011bc020892b76d217106b2903bd4',1,'logica.ValidadorLaberint.validarLaberint(EElement[][] laberint, int costat)']]],
  ['valorarsituacio',['valorarSituacio',['../classlogica_1_1_fantasma3.html#a69e326a7ea8fd47d3d8e4e3f8fd70412',1,'logica::Fantasma3']]],
  ['vullatraparenpacman',['vullAtraparEnPacman',['../classlogica_1_1_fantasma3.html#a9156a1b97e0265824cb2b8c9e235af58',1,'logica::Fantasma3']]]
];
