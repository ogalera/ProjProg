var searchData=
[
  ['calcularmoviment',['calcularMoviment',['../classlogica_1_1_fantasma1.html#ac0020a6fef6ca6779711c58f04d993fc',1,'logica.Fantasma1.calcularMoviment()'],['../classlogica_1_1_fantasma2.html#a0ea5a98c11778bc3b09f66ea5c7a1db1',1,'logica.Fantasma2.calcularMoviment()'],['../classlogica_1_1_item_movible.html#a7851f12b803fe2c87550658ce83c6853',1,'logica.ItemMovible.calcularMoviment()'],['../classlogica_1_1_pacman.html#a4aed3d640e73f08aa1183f9c07b8fc13',1,'logica.Pacman.calcularMoviment()']]],
  ['canviarfrequenciamoviment',['canviarFrequenciaMoviment',['../classlogica_1_1_item_movible.html#a817da6d1c2d5fce6a874edf3b708f147',1,'logica::ItemMovible']]],
  ['canviarpuntuacio',['canviarPuntuacio',['../classinterficie_1_1components_1_1_marcador.html#a69146e4f9b355cfd411a0e7de3c57114',1,'interficie::components::Marcador']]],
  ['carregarimatges',['carregarImatges',['../classinterficie_1_1_f_historic_usuari.html#a3e73a03f41c8150660a7451df269cb7e',1,'interficie::FHistoricUsuari']]],
  ['casella',['Casella',['../classlogica_1_1algoritmica_1_1_casella.html#ab565ddc9c3aced4249653c8163162265',1,'logica::algoritmica::Casella']]],
  ['cim',['cim',['../classlogica_1_1historic__moviments_1_1_pila_3_01_t_01_4.html#ada68762ef342309936234ed5976a5f89',1,'logica::historic_moviments::Pila&lt; T &gt;']]],
  ['clear',['clear',['../classlogica_1_1algoritmica_1_1_llista_ordenada_candidats.html#a0d405bdd9cb347353e4e29c35e064d5d',1,'logica::algoritmica::LlistaOrdenadaCandidats']]],
  ['codificarcadena',['codificarCadena',['../classlogica_1_1_utils.html#a66b968a61334d9723942ad3a9e621fbd',1,'logica::Utils']]],
  ['compareto',['compareTo',['../classlogica_1_1algoritmica_1_1_casella.html#aae2b9f535fd0da3a750f6a6048db1944',1,'logica::algoritmica::Casella']]],
  ['conteelement',['conteElement',['../classlogica_1_1algoritmica_1_1_llista_ordenada_candidats.html#a211e94e69348c4e3c6a5a64991ee4364',1,'logica::algoritmica::LlistaOrdenadaCandidats']]],
  ['creaimatge',['creaImatge',['../classinterficie_1_1components_1_1_marcador.html#a1f7ef632d7bc455a756bcecfe61a9560',1,'interficie::components::Marcador']]],
  ['creapuntuacio',['creaPuntuacio',['../classinterficie_1_1components_1_1_marcador.html#a56c3f7d8a42f4032d040448fd4c079cf',1,'interficie::components::Marcador']]],
  ['crearenemic',['crearEnemic',['../classlogica_1_1_partida.html#aca02d96c8f54d70a8bfa12927e75ba49',1,'logica::Partida']]],
  ['crearmatriu',['crearMatriu',['../classinterficie_1_1_f_editor_laberint.html#a4cf31868202875a1b711982c7c8ecc8f',1,'interficie::FEditorLaberint']]],
  ['crearmenu',['crearMenu',['../classinterficie_1_1_f_editor_laberint.html#a90b765b7d6bedccdfc6573ab74f34019',1,'interficie::FEditorLaberint']]],
  ['crearpacman',['crearPacman',['../classlogica_1_1_partida.html#aff3942c516b8a711b3d13e09453f5c67',1,'logica::Partida']]],
  ['creartaules',['crearTaules',['../classdades_1_1_b_d.html#a7049b625a7b791b7fcf4859487eba09f',1,'dades::BD']]],
  ['creavisualitzaciotemps',['creaVisualitzacioTemps',['../classinterficie_1_1components_1_1_crono.html#a9bbe11279ed444c01881a7babbc500d2',1,'interficie::components::Crono']]],
  ['crono',['Crono',['../classinterficie_1_1components_1_1_crono.html#afd62bd4f1354e15c5b7048c4f874bae3',1,'interficie::components::Crono']]]
];
