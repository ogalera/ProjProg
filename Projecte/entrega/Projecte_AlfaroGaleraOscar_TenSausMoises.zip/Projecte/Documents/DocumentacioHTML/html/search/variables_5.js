var searchData=
[
  ['fila',['fila',['../classlogica_1_1_punt.html#a34834a8a3fba60abcf1f24875adada16',1,'logica::Punt']]],
  ['frequencia',['frequencia',['../classlogica_1_1_item_movible.html#a1b3a9d9e664cfe044d60cbe083dc7919',1,'logica::ItemMovible']]],
  ['frequencia_5fitem',['FREQUENCIA_ITEM',['../classlogica_1_1_utils_1_1_constants.html#ad2b8757e8f32d324463b06fdc5795f39',1,'logica::Utils::Constants']]],
  ['frequencia_5fpersonatge',['FREQUENCIA_PERSONATGE',['../classlogica_1_1_utils_1_1_constants.html#ab1b0f9897e96ea902dcd99db6fc47cc2',1,'logica::Utils::Constants']]],
  ['fugir',['FUGIR',['../enumlogica_1_1_fantasma3_1_1_e_mode.html#aacfca5adc0f5fa09c1776bc53234f341',1,'logica::Fantasma3::EMode']]]
];
