var searchData=
[
  ['objectiu',['objectiu',['../classlogica_1_1_fantasma3.html#a13e89583eb5f6a4fb3f41595833a9b79',1,'logica::Fantasma3']]],
  ['opt',['opt',['../classlogica_1_1algoritmica_1_1_back_tracking_1_1_buscador_cami_maxim.html#a553e2d1a2a45fc88eab631bee7ec38aa',1,'logica::algoritmica::BackTracking::BuscadorCamiMaxim']]]
];
