var searchData=
[
  ['nivellsuperat',['nivellSuperat',['../classdades_1_1_b_d.html#aee65076de634577866799db9ea3315b8',1,'dades::BD']]],
  ['node',['Node',['../classlogica_1_1historic__moviments_1_1_pila_3_01_t_01_4_1_1_node.html#ac26792f334201ca1488cbb6d538a169f',1,'logica::historic_moviments::Pila&lt; T &gt;::Node']]],
  ['nomitemmovible',['nomItemMovible',['../classlogica_1_1_item.html#a729ac980199af2b84c3dc6ef14b57e43',1,'logica.Item.nomItemMovible()'],['../classlogica_1_1_item_movible.html#a2b829b28d6b604e11b8135b78ce8f7eb',1,'logica.ItemMovible.nomItemMovible()']]],
  ['noprocessat',['noProcessat',['../classlogica_1_1algoritmica_1_1_casella.html#a081ffe85bdbe5d97b330c40d2881a74f',1,'logica::algoritmica::Casella']]],
  ['notificarperduaestat',['notificarPerduaEstat',['../classlogica_1_1_fantasma1.html#affe46017be82b1f54e68c41364a69fe3',1,'logica.Fantasma1.notificarPerduaEstat()'],['../classlogica_1_1_fantasma2.html#a7a334328a30cc606d6b995904fffb3c7',1,'logica.Fantasma2.notificarPerduaEstat()'],['../classlogica_1_1_personatge.html#add25ab819bc64920f353eedeac26efcf',1,'logica.Personatge.notificarPerduaEstat()']]],
  ['noumoviment',['nouMoviment',['../classlogica_1_1_pacman.html#af0a24ddada5f8bb327e8dd413478a8a8',1,'logica::Pacman']]],
  ['numeromonedes',['numeroMonedes',['../classlogica_1_1laberints_1_1_laberint.html#a0eb77e8f02d64a81ce07dd6851c55603',1,'logica::laberints::Laberint']]]
];
