var searchData=
[
  ['url_5fbd',['URL_BD',['../classdades_1_1_b_d.html#abc83c541acdcd0be2ae8a33daa753077',1,'dades::BD']]],
  ['usuari',['usuari',['../classinterficie_1_1_f_login.html#ab22f042e985a7d97bb5a07ffd2585fa5',1,'interficie::FLogin']]],
  ['usuaris',['usuaris',['../classinterficie_1_1_f_ranking.html#a09dc89316e366fa4fe26bf19dcd5d692',1,'interficie::FRanking']]]
];
