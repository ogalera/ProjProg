var searchData=
[
  ['usuari',['Usuari',['../classlogica_1_1_usuari.html',1,'logica']]],
  ['utils',['Utils',['../classlogica_1_1_utils.html',1,'logica']]]
];
