var searchData=
[
  ['gestorcami',['gestorCami',['../classlogica_1_1_fantasma3.html#a57dabe0804fa3f0ed00b28f3cab4d6b6',1,'logica.Fantasma3.gestorCami()'],['../classlogica_1_1_item.html#a493a6d454882564c734d0f625ae7998b',1,'logica.Item.gestorCami()']]],
  ['guanya',['guanya',['../classlogica_1_1_personatge.html#a0c30dc6ca85f941043ae4a27e7583c67',1,'logica::Personatge']]]
];
