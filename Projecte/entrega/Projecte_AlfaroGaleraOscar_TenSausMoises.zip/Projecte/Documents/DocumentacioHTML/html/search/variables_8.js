var searchData=
[
  ['id',['id',['../enumlogica_1_1enumeracions_1_1_e_element.html#a276fc494132bca06ef0e2e8490888a01',1,'logica.enumeracions.EElement.id()'],['../classlogica_1_1_usuari.html#a03e97d4f96974eabebd5b15c95267cdf',1,'logica.Usuari.id()']]],
  ['imatge',['imatge',['../enumlogica_1_1enumeracions_1_1_e_element.html#a88d2ec584346f09066becb195b96d8a9',1,'logica::enumeracions::EElement']]],
  ['imatgeperfil',['imatgePerfil',['../classlogica_1_1_item_movible.html#a156a60365745803d0d3298b83aeacb73',1,'logica.ItemMovible.imatgePerfil()'],['../classlogica_1_1_usuari.html#a1ff0cdb0042dc250575386b841111ec1',1,'logica.Usuari.imatgePerfil()']]],
  ['imatgeredimensionada',['imatgeRedimensionada',['../classinterficie_1_1_f_alta.html#ad489c239315b7f8b5206017f668b383c',1,'interficie::FAlta']]],
  ['imatges',['imatges',['../classlogica_1_1_personatge.html#a066a8096f86141bc7a7400cca4c18a7b',1,'logica::Personatge']]],
  ['incrementcolumna',['incrementColumna',['../enumlogica_1_1enumeracions_1_1_e_direccio.html#a55188904e0a2d50611f032d0fed63fac',1,'logica::enumeracions::EDireccio']]],
  ['incrementfila',['incrementFila',['../enumlogica_1_1enumeracions_1_1_e_direccio.html#a7f54d2a6315924892ed78da3635a6358',1,'logica::enumeracions::EDireccio']]],
  ['indexdireccioanterior',['indexDireccioAnterior',['../classlogica_1_1_personatge.html#a9ee15210d2e76e1be387aad61b8d3698',1,'logica::Personatge']]],
  ['itemenemic',['itemEnemic',['../classinterficie_1_1_f_partida.html#abe23e279e0547f67d0e228cc8bdf4c21',1,'interficie::FPartida']]],
  ['itemespecial',['itemEspecial',['../classlogica_1_1_partida.html#a2dcb6e6acb80d2c285796cf4a61635a2',1,'logica::Partida']]],
  ['itempacman',['itemPacman',['../classinterficie_1_1_f_partida.html#af864c7289d6462d5c8b4742047f32b57',1,'interficie::FPartida']]]
];
