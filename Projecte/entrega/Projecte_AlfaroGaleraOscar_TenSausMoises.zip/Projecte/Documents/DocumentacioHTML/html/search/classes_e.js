var searchData=
[
  ['tascaaplicarmoviment',['TascaAplicarMoviment',['../classlogica_1_1_item_movible_1_1_tasca_aplicar_moviment.html',1,'logica::ItemMovible']]]
];
