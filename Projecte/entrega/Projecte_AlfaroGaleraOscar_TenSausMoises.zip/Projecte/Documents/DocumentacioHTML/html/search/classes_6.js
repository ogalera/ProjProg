var searchData=
[
  ['historicmoviments',['HistoricMoviments',['../classlogica_1_1historic__moviments_1_1_historic_moviments.html',1,'logica::historic_moviments']]]
];
