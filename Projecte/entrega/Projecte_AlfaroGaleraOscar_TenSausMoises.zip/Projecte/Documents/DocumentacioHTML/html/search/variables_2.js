var searchData=
[
  ['cim',['cim',['../classlogica_1_1historic__moviments_1_1_pila_3_01_t_01_4.html#aadeb0cd8bcf7f880f2bd1b878d3d238b',1,'logica::historic_moviments::Pila&lt; T &gt;']]],
  ['clase',['clase',['../classlogica_1_1log_1_1_log.html#af7d3b68ff7c0d75c4bfda5364b37b2ad',1,'logica::log::Log']]],
  ['columna',['columna',['../classlogica_1_1_punt.html#a3ad06f8482defd7f0306107e747f714e',1,'logica::Punt']]],
  ['costat',['costat',['../classinterficie_1_1_f_editor_laberint.html#a8715aa165dbd6c01e0f4470a4b11fca6',1,'interficie.FEditorLaberint.costat()'],['../classlogica_1_1laberints_1_1_laberint.html#ae874ac4889592b811709f5b967d85286',1,'logica.laberints.Laberint.costat()'],['../classlogica_1_1_validador_laberint_1_1_particio.html#aea17b1b87c85801a9ee677412b702e83',1,'logica.ValidadorLaberint.Particio.costat()']]],
  ['costatlaberint',['costatLaberint',['../enumlogica_1_1_usuari_1_1_e_nivells.html#a95c4ccbfb2ff5c63780c96e43e07b840',1,'logica::Usuari::ENivells']]]
];
