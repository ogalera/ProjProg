var searchData=
[
  ['random',['random',['../classlogica_1_1_utils.html#adc9eb4b869cd26ba31978a43ff71f80f',1,'logica::Utils']]],
  ['registres',['registres',['../classlogica_1_1log_1_1_log.html#a075fe817fdb417775e67909399d8437c',1,'logica::log::Log']]],
  ['ruta',['ruta',['../classlogica_1_1_fantasma3.html#a270da1ca223914034c125b12479973b1',1,'logica.Fantasma3.ruta()'],['../classlogica_1_1_item.html#aad60c443c720c3c976474593dec685cc',1,'logica.Item.ruta()']]],
  ['rutaimatgedefecteusuari',['rutaImatgeDefecteUsuari',['../classlogica_1_1_utils_1_1_constants.html#ade48d3523c996d6ddcc9b01e7443f314',1,'logica::Utils::Constants']]]
];
