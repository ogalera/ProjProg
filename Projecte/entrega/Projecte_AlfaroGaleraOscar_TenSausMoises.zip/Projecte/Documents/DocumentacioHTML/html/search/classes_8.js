var searchData=
[
  ['laberint',['Laberint',['../classlogica_1_1laberints_1_1_laberint.html',1,'logica::laberints']]],
  ['laberintaleatori',['LaberintAleatori',['../classlogica_1_1laberints_1_1_laberint_aleatori.html',1,'logica::laberints']]],
  ['laberintlinealhoritzontal',['LaberintLinealHoritzontal',['../classlogica_1_1laberints_1_1_laberint_lineal_horitzontal.html',1,'logica::laberints']]],
  ['laberintlinealvertical',['LaberintLinealVertical',['../classlogica_1_1laberints_1_1_laberint_lineal_vertical.html',1,'logica::laberints']]],
  ['llistaordenadacandidats',['LlistaOrdenadaCandidats',['../classlogica_1_1algoritmica_1_1_llista_ordenada_candidats.html',1,'logica::algoritmica']]],
  ['log',['Log',['../classlogica_1_1log_1_1_log.html',1,'logica::log']]]
];
