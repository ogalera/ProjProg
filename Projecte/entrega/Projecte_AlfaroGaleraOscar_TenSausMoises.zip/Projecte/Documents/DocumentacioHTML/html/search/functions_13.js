var searchData=
[
  ['usuari',['Usuari',['../classlogica_1_1_usuari.html#a7d61fbf17076f5c75841d30598ee3289',1,'logica::Usuari']]]
];
