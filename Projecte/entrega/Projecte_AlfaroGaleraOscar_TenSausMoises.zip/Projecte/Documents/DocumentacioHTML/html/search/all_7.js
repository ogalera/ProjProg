var searchData=
[
  ['haestatprocessat',['haEstatProcessat',['../classlogica_1_1algoritmica_1_1_casella.html#a79b54543059fa328c5d18a96d694cf54',1,'logica::algoritmica::Casella']]],
  ['hihaitemespecial',['hiHaItemEspecial',['../classlogica_1_1_partida.html#acacc85c1923ed99015b4311557843d2f',1,'logica::Partida']]],
  ['hihaitemespecialaprop',['hiHaItemEspecialAProp',['../classlogica_1_1_fantasma3.html#a233382b72cb5b1293e1517f0b13c15f4',1,'logica::Fantasma3']]],
  ['historicmoviments',['historicMoviments',['../classlogica_1_1_personatge.html#a86322efbc950e2954fe2a8cde806bbd9',1,'logica.Personatge.historicMoviments()'],['../classlogica_1_1historic__moviments_1_1_historic_moviments.html#a495dab908c92d96be0111a337aa64616',1,'logica.historic_moviments.HistoricMoviments.HistoricMoviments()']]],
  ['historicmoviments',['HistoricMoviments',['../classlogica_1_1historic__moviments_1_1_historic_moviments.html',1,'logica::historic_moviments']]]
];
