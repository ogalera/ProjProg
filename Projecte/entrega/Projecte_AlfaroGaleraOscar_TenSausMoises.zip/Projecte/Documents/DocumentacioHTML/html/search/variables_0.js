var searchData=
[
  ['act',['act',['../classlogica_1_1algoritmica_1_1_back_tracking_1_1_buscador_cami_maxim.html#a96bcdeb2c28a4383c48cf6a0eaad90d1',1,'logica::algoritmica::BackTracking::BuscadorCamiMaxim']]]
];
