var searchData=
[
  ['historicmoviments',['historicMoviments',['../classlogica_1_1_personatge.html#a86322efbc950e2954fe2a8cde806bbd9',1,'logica::Personatge']]]
];
