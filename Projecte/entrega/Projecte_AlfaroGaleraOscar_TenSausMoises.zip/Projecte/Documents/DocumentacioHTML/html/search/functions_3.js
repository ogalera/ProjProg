var searchData=
[
  ['desanotar',['desanotar',['../classlogica_1_1algoritmica_1_1_back_tracking_1_1_solucio.html#a5d31926a0ae53314d9757bb3f560a69f',1,'logica::algoritmica::BackTracking::Solucio']]],
  ['desenpilar',['desenpilar',['../classlogica_1_1historic__moviments_1_1_pila_3_01_t_01_4.html#a4eee9c634e4eb6a3a7fe84132374cee5',1,'logica::historic_moviments::Pila&lt; T &gt;']]],
  ['destivalid',['destiValid',['../classlogica_1_1_item.html#ab86860a660ef6b665576245110578878',1,'logica::Item']]],
  ['distancia',['distancia',['../classlogica_1_1_punt.html#a20bb4168bbedb81b73947bfeaf31512a',1,'logica::Punt']]],
  ['distanciaminima',['distanciaMinima',['../classlogica_1_1laberints_1_1_laberint_aleatori.html#adea89761d3eeba42d9e833ffc707d234',1,'logica::laberints::LaberintAleatori']]]
];
