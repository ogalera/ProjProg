var searchData=
[
  ['nelement',['nElement',['../classlogica_1_1historic__moviments_1_1_historic_moviments.html#af68217808f9cd72e0f40bb11bdda5f03',1,'logica::historic_moviments::HistoricMoviments']]],
  ['nivell',['nivell',['../classlogica_1_1_usuari.html#af876e9fe1520077525154738abadc8ef',1,'logica::Usuari']]],
  ['nmondesperitem',['nMondesPerItem',['../classlogica_1_1laberints_1_1_laberint.html#a65b89b5e73ed4533df3a8c2296e492be',1,'logica::laberints::Laberint']]],
  ['nmonedes',['nMonedes',['../classlogica_1_1laberints_1_1_laberint.html#af1c4b00f98c8109c6bb2c7aadedd024d',1,'logica::laberints::Laberint']]],
  ['nom_5fbd',['NOM_BD',['../classdades_1_1_b_d.html#a0244ade6a6066ad9f59f8f8e9b2e034e',1,'dades::BD']]],
  ['nomesultimmissatge',['nomesUltimMissatge',['../classinterficie_1_1_f_log.html#a31329112410d3afd9a40a210a9142dcb',1,'interficie::FLog']]],
  ['nomusuari',['nomUsuari',['../classlogica_1_1_usuari.html#a786e8efb6a09a1cc3678d4103606319a',1,'logica::Usuari']]],
  ['nparticions',['nParticions',['../classlogica_1_1_validador_laberint_1_1_particio.html#a89a4308fa4580773cf760520740aa6ef',1,'logica::ValidadorLaberint::Particio']]]
];
