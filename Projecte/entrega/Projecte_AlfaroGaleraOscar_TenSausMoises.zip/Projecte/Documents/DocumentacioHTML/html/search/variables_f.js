var searchData=
[
  ['seguent',['seguent',['../classlogica_1_1historic__moviments_1_1_pila_3_01_t_01_4_1_1_node.html#aeb64a3ab73d46d75a57405c0c20c34de',1,'logica::historic_moviments::Pila&lt; T &gt;::Node']]],
  ['seguentmoviment',['seguentMoviment',['../classlogica_1_1_item_movible.html#a6e7ab9e5b0e363972a753e6b1550e7fb',1,'logica::ItemMovible']]],
  ['seguiment',['SEGUIMENT',['../enumlogica_1_1_fantasma3_1_1_e_mode.html#a96323a795182c39b55457ff5b990bc32',1,'logica::Fantasma3::EMode']]]
];
