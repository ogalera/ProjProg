var searchData=
[
  ['icontrolador',['IControlador',['../interfacelogica_1_1controladors__pacman_1_1_i_controlador.html',1,'logica::controladors_pacman']]],
  ['ipintadorlaberint',['IPintadorLaberint',['../interfaceinterficie_1_1_i_pintador_laberint.html',1,'interficie']]],
  ['ipintadorpartida',['IPintadorPartida',['../interfaceinterficie_1_1_i_pintador_partida.html',1,'interficie']]],
  ['item',['Item',['../classlogica_1_1_item.html',1,'logica']]],
  ['itemmovible',['ItemMovible',['../classlogica_1_1_item_movible.html',1,'logica']]]
];
