var searchData=
[
  ['quedenmonedes',['quedenMonedes',['../classlogica_1_1_fantasma3.html#a975dd968c3874e23ca8956d3490ae055',1,'logica::Fantasma3']]]
];
