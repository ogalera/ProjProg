var searchData=
[
  ['generarcandidats',['generarCandidats',['../classlogica_1_1algoritmica_1_1_back_tracking_1_1_solucio.html#a75cbbd1737092ae156d31d27f6a9744f',1,'logica::algoritmica::BackTracking::Solucio']]],
  ['generarlaberint',['generarLaberint',['../classlogica_1_1laberints_1_1_laberint_aleatori.html#a8a24d71239fade75e2d70df929d84953',1,'logica.laberints.LaberintAleatori.generarLaberint()'],['../classlogica_1_1laberints_1_1_laberint_lineal_horitzontal.html#a6f3432d9ea0def617be88ac62c55c787',1,'logica.laberints.LaberintLinealHoritzontal.generarLaberint()'],['../classlogica_1_1laberints_1_1_laberint_lineal_vertical.html#a866046523691d72367ba28ec8bb83bbc',1,'logica.laberints.LaberintLinealVertical.generarLaberint()']]],
  ['generarpuntdesplasat',['generarPuntDesplasat',['../classlogica_1_1_punt.html#a8198234b3d10d9f83e634b0390c84dcb',1,'logica::Punt']]],
  ['generaruta',['generaRuta',['../classlogica_1_1algoritmica_1_1_a_estrella_1_1_buscador_cami_minim.html#a99382c4518dfe3adff49fb8cbef27705',1,'logica.algoritmica.AEstrella.BuscadorCamiMinim.generaRuta()'],['../classlogica_1_1algoritmica_1_1_back_tracking_1_1_solucio.html#ad92451e3b29a2d5918053827e2996ba8',1,'logica.algoritmica.BackTracking.Solucio.generaRuta()']]],
  ['gestorcami',['gestorCami',['../classlogica_1_1_fantasma3.html#a57dabe0804fa3f0ed00b28f3cab4d6b6',1,'logica.Fantasma3.gestorCami()'],['../classlogica_1_1_item.html#a493a6d454882564c734d0f625ae7998b',1,'logica.Item.gestorCami()']]],
  ['gestorcamins',['GestorCamins',['../classlogica_1_1algoritmica_1_1_gestor_camins.html',1,'logica::algoritmica']]],
  ['getinstance',['getInstance',['../classlogica_1_1log_1_1_log.html#ab38bea9cfc1ad368b40a2773f93d14b8',1,'logica::log::Log']]],
  ['getmissatge',['getMissatge',['../classlogica_1_1log_1_1_log_1_1_parella_prioritat_missatge.html#a7756b4291f85d7041a0ec345b219d8dd',1,'logica::log::Log::ParellaPrioritatMissatge']]],
  ['getnparticions',['getNParticions',['../classlogica_1_1_validador_laberint_1_1_particio.html#a17d7870068d9eb5a9b62b568708faba6',1,'logica::ValidadorLaberint::Particio']]],
  ['getprioritat',['getPrioritat',['../classlogica_1_1log_1_1_log_1_1_parella_prioritat_missatge.html#a4610e88dadbf2838b77f65b128bd7958',1,'logica::log::Log::ParellaPrioritatMissatge']]],
  ['getultimregistredeuntipus',['getUltimRegistreDeUnTipus',['../classlogica_1_1log_1_1_log.html#a9cbdafd1efe82a9210251544c7fce63a',1,'logica::log::Log']]],
  ['guanya',['guanya',['../classlogica_1_1_personatge.html#a0c30dc6ca85f941043ae4a27e7583c67',1,'logica::Personatge']]]
];
